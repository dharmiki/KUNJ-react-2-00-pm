import RegisterForm from "./components/form"

function App() {

  return (
    <>
      <RegisterForm></RegisterForm>
    </>
  )
}

export default App
